package com.springbean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
