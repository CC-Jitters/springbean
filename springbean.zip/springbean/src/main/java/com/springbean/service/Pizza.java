package com.springbean.service;

public interface Pizza {

    String getPizza();

}
