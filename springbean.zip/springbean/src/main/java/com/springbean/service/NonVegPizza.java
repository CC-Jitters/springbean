package com.springbean.service;

// import org.springframework.context.annotation.Primary;
// import org.springframework.stereotype.Component;

// @Component
// @Primary
public class NonVegPizza implements Pizza {

    public String getPizza() {

        return "Non-veg Pizza!";

    }

}
