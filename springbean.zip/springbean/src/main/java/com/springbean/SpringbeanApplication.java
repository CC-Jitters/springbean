package com.springbean;

import com.springbean.controller.PizzaController;
import com.springbean.service.VegPizza;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbeanApplication {

	public static void main(String[] args) {

		var context = SpringApplication.run(SpringbeanApplication.class, args);

		PizzaController pizzaController = (PizzaController) context.getBean("pizzaController");
		System.out.println(pizzaController.getPizza());

//		VegPizza vegPizza = context.getBean(VegPizza.class);
//		VegPizza vegPizza = (VegPizza) context.getBean("vegPizzaBean");
//		VegPizza vegPizza = (VegPizza) context.getBean("vegPizza");
//		System.out.println(vegPizza.getPizza());

	}

}
