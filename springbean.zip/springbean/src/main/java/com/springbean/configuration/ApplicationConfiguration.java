package com.springbean.configuration;

import com.springbean.controller.PizzaController;
import com.springbean.service.NonVegPizza;
import com.springbean.service.Pizza;
import com.springbean.service.VegPizza;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {

    //@Bean(name = "vegPizzaBean")
    @Bean
    public Pizza vegPizza() {

        return new VegPizza();

    }

    @Bean
    public Pizza nonVegPizza() {

        return new NonVegPizza();

    }

    @Bean(initMethod = "init", destroyMethod = "destroy")
    public PizzaController pizzaController() {

        return new PizzaController(nonVegPizza());

    }

}
