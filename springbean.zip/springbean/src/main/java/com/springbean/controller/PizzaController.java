package com.springbean.controller;

import com.springbean.service.Pizza;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.web.bind.annotation.RestController;

// @RestController
public class PizzaController {

    private Pizza pizza;

    // @Autowired
    public PizzaController(Pizza pizza) {

        this.pizza = pizza;

    }

    public String getPizza() {

        return pizza.getPizza();

    }

    public void init() {

        System.out.println("Initialization Logic!");

    }

    public void destroy() {

        System.out.println("Destruction Logic!");

    }

}
